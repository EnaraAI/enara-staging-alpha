# ENARA r4.2 review report: 40 tutoring cases, package and rubric

Nov 10, 2026 · @Mohamed Saber

## Summary

I scored all 40 cases on the ten criteria: 39 meet expectations, 1 partially meets (EXP-C58A), and none has a critical defect. These are AI scores, so they cannot stand in for either of the two human educators the package requires.

- **Tutor strengths.** Task alignment, grounding, grammar accuracy and age fit are near ceiling. The tutor never confirmed a wrong answer, never claimed mastery, and never did off-topic work.
- **Tutor weakness.** Hint quality (C7) is the weakest criterion, mean 3.04 on 27 scored cases. The tutor routinely states the rule before the learner's first attempt, and in three cases the hint gives away most or all of the answer.
- **One major defect.** In EXP-C58A the tutor writes "watch → watches" and then sets "My dad watch TV" in the same reply.
- **Package.** The evidence in the A and B packages is identical apart from case order. Three design points could bias human scores or the agreement statistics; they are listed under Package findings.
- **Rubric.** My scores support reporting short cases separately and treating pre-attempt cues as a ruling the educators must make before C7 can be scored consistently.

## Scope and limits

This is an AI second opinion on the package, not the independent human validation the README calls for.

- **Not a reviewer A or B.** The procedure requires two qualified EFL educators scoring with "no AI information". Keep this report and the score sheet away from both reviewers until both have submitted.
- **Not blind in the package's sense.** I read both reviewer packages, the README and the rubric decision worksheet, including the aggregate automated figures in decisions 5 and 9. I checked that A and B contain the same 40 cases with the same text; only the order differs.
- **What I did not have.** The restricted files (case mapping, calibration flags, automated evaluator results, reserve cases), the validation report, the manifest and the reviewer CSV templates were not provided. I cannot say which cases are calibration controls or compare my scores with the automated ones.
- **How I scored.** I used the 0–4 scale and criteria C1–C10 as written in the reviewer package, with my own judgement and not the draft rubric anchors. Quotes are given for every score below 3.
- **Evidence base.** One transcript per case, as supplied. The other two runs per case sit in the restricted files.

## Findings on the tutor

The tutor is accurate and well aligned, and its recurring weakness is giving too much help too early.

| Criterion | Cases scored | Mean (0–4) | Scores of 4 | Scores of 3 | Scores of 2 or below | NA |
| --- | --- | --- | --- | --- | --- | --- |
| C1 Task alignment | 40 | 4.00 | 40 | 0 | 0 | 0 |
| C2 Age appropriateness | 40 | 3.92 | 37 | 3 | 0 | 0 |
| C3 Answer correctness | 22 | 3.86 | 19 | 3 | 0 | 18 |
| C4 Grounding | 40 | 3.92 | 37 | 3 | 0 | 0 |
| C5 Grammar | 37 | 3.89 | 33 | 4 | 0 | 3 |
| C6 CEFR appropriateness | 40 | 3.70 | 29 | 10 | 1 | 0 |
| C7 Hint quality and leakage | 27 | 3.04 | 5 | 19 | 3 | 13 |
| C8 Formative assessment | 37 | 3.43 | 17 | 19 | 1 | 3 |
| C10 Overall instructional quality | 40 | 3.70 | 29 | 10 | 1 | 0 |

C9 evidence sufficiency: 22 cases Sufficient, 18 Limited, none Insufficient. Every Limited case is one exchange, or two turns with no learner attempt.

**What the tutor does well**

- **Answer judgement.** In all 22 cases with a learner answer, the tutor classified it correctly: correct, partly correct, or wrong. It credited what was right ("usually" placed correctly, "have visited" well formed) before addressing the error.
- **Retry before reveal.** In every answer-request case it declined to give the answer and offered a hint. In every error case it asked for a retry.
- **No mastery claims.** After hinted success it said so ("You fixed this one after a hint") and set an independent item. After repeated success it moved to a freer task without percentages or "mastered".
- **Change of approach.** Both repeated-misconception cases (EXP-79B4, EXP-C51A) switched to a minimal pair and a smaller step.
- **Boundaries.** Off-topic requests were declined briefly and redirected. Missing-context cases got one goal question with options.
- **Length.** No tutor reply came within 10% of its word limit.

**Recurring weaknesses**

- **Rule before attempt.** When asked for "one exercise", the tutor usually prefaces it with the governing rule and a parallel example. The first attempt then shows little about what the learner knows. This drives most of the 19 C7 scores of 3.
- **Support not reduced after success.** In EXP-30B8, EXP-EE3F, EXP-FC03 and EXP-892B the tutor adds or keeps cues on the second item after a correct first answer.
- **Answer inside the hint.** EXP-C58A and EXP-D688 show the target form in the hint text. EXP-8643 comes close ("Which word do we use for him?").
- **Unevidenced praise of process.** EXP-30B8 and EXP-D76F credit the learner with a strategy ("You checked the subject first") that the transcript does not show.
- **Level slips at A1.** Wordy meta-comments and one check question (EXP-4137) are harder than the content they support.
- **Artefact.** EXP-892B shows internal labels "\[ex1\]" and "\[ex2\]" to the learner.

## Cases needing attention

Four cases have a score below 3; one of them carries a major defect.

| Case | Learner | Score | Evidence (verbatim, turn) | Why it matters |
| --- | --- | --- | --- | --- |
| EXP-C58A | teen A2 | C7 = 1, C8 = 2, C10 = 2. Major defect. Partially meets. | "Other verbs like this: do → does, watch → watches." (Turn 2), then in the same reply: "Correct the verb: 'My dad watch TV after dinner.'" | The answer to the next item is printed just before the item. The learner's next answer is no evidence of learning. |
| EXP-D688 | child A2 | C7 = 2 | "Who goes to bed? Check the word go again." (Turn 2) | The hint contains "goes", the form the learner is being asked to find. |
| EXP-892B | adult B1 | C7 = 2 | "Before you write, look at the word ever. It asks about any time in your life up to now, not a specific finished time." (Turn 2) | The learner had just answered item 1 correctly. The tutor then explains the deciding point of item 2 before any attempt. |
| EXP-4137 | adult A1 | C6 = 2 | "Quick check: your mother's daughter (not you) is your mother or your sister?" (Turn 1) | The check needs a possessive, a parenthesis and an uninverted question. It is harder than the word "sister" that the A1 learner asked about. |

The major-defect call on EXP-C58A is a judgement: the confirmation part of that turn is correct, and a reviewer could reasonably flag it as a C7 problem only. The same scenario in EXP-DBC7 is handled without the leak ("Verbs like do work the same way").

## Full score table

All 40 cases, in Reviewer A package order. C1–C8 and C10 use the 0–4 scale; NA means the criterion cannot apply. The same scores, with quotes, are in the score sheet CSV delivered with this report.

| Case | Learner | Turns | C1 | C2 | C3 | C4 | C5 | C6 | C7 | C8 | C9 | C10 | Overall | Note |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| EXP-E1E0 | child A2 | 1 | 4 | 4 | NA | 4 | NA | 4 | NA | NA | Limited | 4 | Meets | One short goal question with three child-sized options; invents nothing. |
| EXP-69EC | teen B1 | 1 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | Sufficient | 4 | Meets | Credits the form, points at 'yesterday', asks for rewrite plus reason. Does not lean on the 'proficient' record. |
| EXP-8643 | child A1 | 2 | 4 | 4 | NA | 4 | 4 | 3 | 3 | 3 | Limited | 3 | Meets | Declines to hand over the answer. Hint 'Which word do we use for him?' all but names the pronoun. |
| EXP-0F07 | child B1 | 2 | 4 | 4 | NA | 4 | 4 | 4 | 3 | 4 | Limited | 4 | Meets | Tip plus parallel example before any attempt; second hint still leaves 'visited' to the learner. |
| EXP-07EE | child B1 | 1 | 4 | 4 | NA | 4 | 4 | 4 | NA | 4 | Limited | 4 | Meets | Corrects the misunderstanding with a clean contrast pair and a production frame. |
| EXP-60A0 | child A2 | 2 | 4 | 4 | 3 | 4 | 4 | 3 | 3 | 3 | Sufficient | 3 | Meets | Rule stated before the attempt. Feedback targets 'went' but ignores the 'Yesterday she go' clause. |
| EXP-93CD | teen A2 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 3 | 4 | Sufficient | 4 | Meets | Graduated support over four turns, explicit 'on your own' item, no mastery claim. Rule stated before first attempt. |
| EXP-EEE8 | teen B1 | 2 | 4 | 4 | 4 | 4 | 4 | 4 | 3 | 3 | Sufficient | 4 | Meets | Clear confirmation and a light note on the capital letter. Turn 1 example states the rule and its reason before the attempt. |
| EXP-A449 | teen A2 | 1 | 4 | 4 | NA | 4 | 3 | 3 | 3 | 3 | Limited | 3 | Meets | Gives 'every day' and 'always', but also hands over 'wakes' unasked, so the follow-up only tests word order. Three points in one reply. |
| EXP-4A7E | teen B1 | 1 | 4 | 4 | NA | 4 | 4 | 4 | NA | 4 | Limited | 4 | Meets | Gives 'been to' with models and a two-sentence production task on the lesson contrast. |
| EXP-F274 | adult B1 | 1 | 4 | 4 | NA | 4 | NA | 4 | NA | NA | Limited | 4 | Meets | One goal question with adult-appropriate options; invents nothing. |
| EXP-A5A6 | teen A1 | 1 | 4 | 3 | NA | 4 | 4 | 3 | NA | 3 | Limited | 4 | Meets | Firm boundary and redirect to the lesson item. A little curt; no bridge from the pyramids topic to English. |
| EXP-30B8 | teen A2 | 3 | 4 | 4 | 4 | 3 | 4 | 4 | 3 | 4 | Sufficient | 4 | Meets | Moves to a freer task after two correct answers, no mastery claim. Repeats the tip on item 2 after success; 'You checked the subject first' is not evidenced. |
| EXP-A3B8 | adult A2 | 1 | 4 | 4 | NA | 4 | 3 | 4 | NA | 3 | Limited | 3 | Meets | Office examples fit an adult. Rule says 'add -s' yet the check uses 'have' (has), an irregular the rule does not cover. |
| EXP-C58A | teen A2 | 2 | 4 | 4 | 4 | 4 | 4 | 4 | 1 | 2 | Sufficient | 2 | Partially meets | Correct confirmation of the self-correction, then the tutor lists 'watch → watches' and immediately sets 'My dad watch TV'. Major defect. |
| EXP-C23F | adult A2 | 2 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | Sufficient | 4 | Meets | Model partial-credit turn: credits 'usually', isolates subject and verb, asks which group 'She' is in, retry. |
| EXP-A337 | child A1 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 3 | 4 | Sufficient | 4 | Meets | Warm, short, child-fit. Hinted success treated as progress, 'no tip' item, targeted retry. Turn 1 tip names the deciding fact (boy or girl). |
| EXP-1876 | teen A1 | 4 | 4 | 4 | 4 | 4 | 4 | 3 | 3 | 4 | Sufficient | 4 | Meets | Same strong sequence; 'You fixed this one after a hint' is explicit. Some phrasing is wordy for A1. |
| EXP-633C | teen A1 | 2 | 4 | 4 | 4 | 4 | 4 | 3 | 4 | 3 | Sufficient | 4 | Meets | Handles 'Mother is twelve' precisely: the gap word is not a family word. No leakage. |
| EXP-7454 | child B1 | 2 | 4 | 3 | 4 | 4 | 4 | 3 | 3 | 4 | Sufficient | 4 | Meets | Credits 'have visited', points to 'last year', defers the second sentence. Metalanguage is heavy for a child. |
| EXP-6DE8 | child A1 | 1 | 4 | 3 | NA | 4 | 3 | 4 | NA | 4 | Limited | 3 | Meets | Clear contrast and a good one-word check. 'The woman who has you' is unnatural English; 'same mum and dad' assumes a family shape. |
| EXP-BFFE | child A1 | 1 | 4 | 4 | NA | 4 | 4 | 4 | NA | 3 | Limited | 4 | Meets | Direct words, accurate Arabic gloss, tiny production prompt. 'Point to Baba in a picture' refers to a picture that does not exist. |
| EXP-79B4 | adult A2 | 3 | 4 | 4 | 3 | 4 | 4 | 4 | 4 | 4 | Sufficient | 4 | Meets | Changes approach on the repeat error: minimal pair plus a smaller classification step. Turn 2 opens 'Good.' on a sentence containing the target error. |
| EXP-554D | teen A2 | 2 | 4 | 4 | 4 | 4 | 4 | 4 | 3 | 3 | Sufficient | 4 | Meets | Accurate partial credit and retry. The hint repeats the same two questions instead of narrowing. |
| EXP-892B | adult B1 | 2 | 4 | 4 | 4 | 4 | 4 | 4 | 2 | 3 | Sufficient | 3 | Meets | Confirmation and capital-letter note are well judged. Support rises after success: the tutor explains 'ever' before the learner tries item 2. Internal exercise labels shown to the learner. |
| EXP-5B83 | teen A2 | 2 | 4 | 4 | NA | 4 | 4 | 4 | 3 | 3 | Limited | 4 | Meets | Good-humoured refusal to give the answer; hint 'does go match She?' leaves the form to the learner. |
| EXP-EEE1 | child A2 | 3 | 4 | 4 | 4 | 4 | 4 | 4 | 3 | 4 | Sufficient | 4 | Meets | Drops the tip on item 2, then sets a freer task. No mastery claim. Rule stated before first attempt. |
| EXP-D688 | child A2 | 2 | 4 | 4 | 4 | 4 | 4 | 4 | 2 | 3 | Sufficient | 3 | Meets | Good partial credit, but the hint itself contains the target form. |
| EXP-96EB | teen A1 | 2 | 4 | 4 | NA | 4 | 4 | 3 | 3 | 3 | Limited | 3 | Meets | Holds the line on trying first. Rule is given in full in turn 1, then the hint asks 'boy or girl?', leaving only a lookup. |
| EXP-679F | child B1 | 1 | 4 | 4 | NA | 4 | 4 | 3 | NA | 3 | Limited | 4 | Meets | Dragon example suits a child and the topic. The check ('draw ... yesterday') follows two lines after 'Drew is the past simple'. |
| EXP-0BF4 | adult A2 | 4 | 4 | 4 | 3 | 4 | 4 | 4 | 3 | 4 | Sufficient | 4 | Meets | Strong sequence and an explicit 'no hint' item. In turn 4 it never says the unchanged sentence is still wrong. |
| EXP-EE3F | adult B1 | 3 | 4 | 4 | 4 | 4 | 4 | 4 | 3 | 4 | Sufficient | 4 | Meets | Recognises the learner's own correct switch and moves to a three-sentence message. Cue questions stay on item 2 after success. |
| EXP-D76F | teen B1 | 3 | 4 | 4 | 4 | 3 | 4 | 4 | 3 | 4 | Sufficient | 4 | Meets | Teen-fit transfer task. 'Checking for time words first is what led you to the answer' is an unevidenced claim about the learner. |
| EXP-3A9B | adult A1 | 1 | 4 | 4 | NA | 4 | NA | 4 | NA | NA | Limited | 4 | Meets | One goal question, simple options, invents nothing. |
| EXP-4137 | adult A1 | 1 | 4 | 4 | NA | 4 | 3 | 2 | NA | 3 | Limited | 3 | Meets | Definitions are clear, but the check question is harder to parse than the word it tests and is not a well-formed question. |
| EXP-C51A | adult B1 | 3 | 4 | 4 | 4 | 4 | 4 | 4 | 4 | 3 | Sufficient | 4 | Meets | Credits form each time, names the repeat, moves to a minimal pair and 'change only the verb'. Never returns to the unanswered a/b check. |
| EXP-2EE9 | child B1 | 1 | 4 | 4 | NA | 4 | 4 | 4 | NA | 3 | Limited | 4 | Meets | Friendly boundary, does not do the sum, links back with a lesson-vocabulary sentence and sets the item. |
| EXP-FC03 | adult A1 | 3 | 4 | 4 | 4 | 4 | 4 | 4 | 3 | 4 | Sufficient | 4 | Meets | Moves to own-sentence task with a frame and self-check. Adds a tip after a correct answer, which raises rather than lowers support. |
| EXP-DBC7 | adult A2 | 2 | 4 | 4 | 4 | 4 | 4 | 4 | 3 | 3 | Sufficient | 4 | Meets | Confirms the self-correction, light apostrophe note, next item. Points at the ending of 'watch' before the attempt but does not give the form. |
| EXP-11FA | child A1 | 1 | 4 | 4 | NA | 3 | 4 | 3 | NA | 3 | Limited | 3 | Meets | Short and on pattern, bridges to family words. Assumes the teacher is a woman; 'introduces a person' is above A1. |

## Findings on the package and workbook

The package is internally consistent, but three design points could bias the human scores and two could distort the agreement statistics.

**Checks that passed**

- Reviewer A and B packages hold the same 40 case IDs with identical case text; only the order differs.
- All 15 case IDs cited as examples in the rubric decision worksheet exist in the packages, and their descriptors (age band, CEFR level, turn count, lesson availability) match the case text.
- The 40 IDs pre-filled in the workbook match the 40 IDs in the packages.
- Neither reviewer package contains automated scores, tiers or the old ADJ ids.

**Risks to blind scoring**

| # | Finding | Where | Effect | Suggested handling |
| --- | --- | --- | --- | --- |
| 1 | Each case shows the scenario label (for example "T07\_hint\_then\_fail") and the designers' expected and unacceptable behaviour. | Every case header and "Case design notes" | Reviewers are told what a good answer looks like before they judge. Scores may measure fit to the design note, and agreement between reviewers may be inflated. | If packages are not yet sent, consider a version without labels and notes. If sent, disclose this as a limitation. |
| 2 | The draft rubric anchors are attached to the blind package as Appendix A. | Appendix A | Reviewers can anchor on the draft they are meant to judge independently later. | Disclose. Ask reviewers to note whether they consulted it. |
| 3 | The rubric worksheet names four cases where an automated evaluator recorded insufficient evidence, and gives aggregate automated pass rates. | Decisions 3, 5, 9 | The README gives the worksheet to reviewers once both have submitted, which is before adjudication in step 4. Adjudication could then be influenced by automated results. | Hand over the worksheet only after adjudication is closed. |
| 4 | In EXP-93CD and EXP-0BF4, turn 4 is labelled a learner attempt, but the learner only repeats the uncorrected prompt. The tutor treats it as no attempt. | Turn labels | Reviewers may split on C3 and C7 depending on whether they follow the label or the text. | Expect a disagreement here; settle it in adjudication, not by relabelling. |

**Risks to the agreement statistics**

- **Ceiling.** In my scoring, C1 is 4 in all 40 cases and C2, C4 and C5 are 4 in at least 33. If the educators score similarly, Cohen's kappa will be near zero or undefined despite high raw agreement. Report exact and within-one agreement beside kappa, and consider Gwet's AC1 or AC2.
- **Thin numeric pairs.** I used NA for C3 in 18 cases and for C7 in 13. Kappa on the 9 calibration cases will rest on very few pairs, or be blank.
- **Numbers pasted as text.** The Comparison sheet tests scores with ISNUMBER. If the CSV paste lands as text, every 0–4 pair is treated as non-numeric and kappa stays blank. Check one cell after pasting.
- **Label matching.** Categories are compared as exact text, with case folded but spaces not trimmed. "Meets" versus "meets expectations" counts as a disagreement. Fix the wording in the score sheets or add dropdowns.
- **Column heading.** For C9 and OVERALL, the "NA/IE disagreements" column counts ordinary category disagreements. Rename it or read it with that in mind.

I read the workbook formulas but did not recalculate the Kappa\_matrices sheet with test data. A dry run with two dummy CSVs before the real paste would confirm it. I did not see the validation report, so I cannot comment on the "disclosed gaps" the README refers to.

## Input on the nine rubric decisions

These are observations from scoring the 40 cases, offered as input. The rulings belong to the two educators and are still open.

| Decision | Option my scoring supports | Evidence from the 40 cases |
| --- | --- | --- |
| 1. Hint strength on two-option items | (b), with item type noted as in (c) | At A1, "Is a brother a boy or a girl?" still left the choice to the learner (EXP-A337, EXP-1876). The line I would draw is the answer form appearing in the tutor's text. EXP-96EB sits on the boundary: full rule plus "boy or girl?" leaves only a lookup. |
| 2. Minimum evidence for MEETS | (c) | 15 cases are a single exchange. I could score C3 in 22 cases and C7 in 27. A one-exchange "meets" and a four-turn "meets" are different claims. |
| 3. Insufficient-evidence rules | (a) | Scoring 3 with a flag creates a number where there is no evidence. I never needed IE; every unscored cell was a clear NA. That suggests IE needs a tighter definition or will be used inconsistently. |
| 4. N/A rules | (a) | My NA uses fell into four situations: no learner answer (C3), no attempt or hint situation (C7), no language claims (C5), goal-clarifying turn (C8). A list like this per criterion would make reviewers' NA choices comparable. |
| 5. Pass threshold | (c) for now, (b) when human scores exist | 36 of 40 cases have no score below 3. Under the draft rule, pass or fail for the other four would turn on one C7 or C6 judgement each. A profile shows that directly. |
| 6. D7 anchors | (c) | Two things are mixed. Whether the answer form was shown before an attempt is a checkable fact (EXP-C58A, EXP-D688). How well the hint is pitched is a graded judgement. The draft anchors also do not say where a rule stated before any attempt belongs, which is this tutor's most common pattern. |
| 7. CEFR anchoring | (b), with exemplars per level | The level problems I found were specific sentences, such as the check question in EXP-4137. Exemplar turns per level would catch those. This is a weaker view than the others; I did not test descriptors against cases. |
| 8. Do the dimensions measure the construct | (a) or (b), plus (c) if affect matters to the product | Several good turns relied on encouragement and tone (EXP-5B83, EXP-A337), and one on Arabic glosses (EXP-BFFE). C2 was the only place to credit them. |
| 9. 5-dimension versus 11-dimension discrepancy | (b), consistent with decision 2 | In my scoring, short cases did not score higher overall: mean C10 was 3.67 for one-turn cases and 4.00 for three- and four-turn cases. That differs from the automated pattern quoted in the worksheet and is worth checking against the human scores. |

## Recommended next steps

1. Proceed with the two human educators as planned. Treat this report as coordinator-only material until both score sheets are in.
2. Before sending, decide whether to remove scenario labels and design notes from the reviewer packages, or to record their presence as a limitation.
3. Dry-run the workbook with two dummy CSVs and confirm that scores land as numbers and kappa cells fill.
4. Hold the rubric decision worksheet back until adjudication is closed.
5. After unsealing, compare three result sets separately: human, automated, and this AI review. EXP-C58A, EXP-D688, EXP-892B and EXP-4137 are the cases where I would expect the sharpest differences.
6. Whatever the rubric outcome, the tutor findings stand on their own: review why the tutor states the rule before a first attempt, and why answer forms appeared in hints in EXP-C58A and EXP-D688. The other two runs of those cases would show whether this repeats.
