# Restricted coordinator findings (r4.2 human review)

**RESTRICTED: coordinator only.**
- This file contains original case ids, automated (AI) results and the coordinator's AI review.
- Do not show it to either reviewer, nor discuss its contents with them, until **both** blind score sheets are submitted **and** adjudication is closed.

**Scope and status:**
- **Read-only analysis** of the existing r4.2 transcripts (3 runs × 120 cases).
- **No tutor code, prompt, rubric or scoring logic was changed.**
- Nothing here is an educator ruling.

## 1. Three result sets, kept separate

| Set | Source | Status |
|---|---|---|
| Automated official evaluator | `v1_restricted_copies/automated_evaluator_comparison_restricted.json` (claude-sonnet-5-5, draft rubric) | Unchanged |
| Automated independent evaluator | same file (claude-haiku-5-5) | Unchanged |
| **Coordinator AI review (third result set)** | `third_result_set_ai_review/ai_review_score_sheet.csv` and `ai_review_report.md`, copied verbatim from the coordinator's upload | Preserved as delivered. Labelled AI, not human. **Never merge it into human scores.** |

On the designated transcripts of the 40 cases, the AI review's overall category was compared with each evaluator's outcome:

| Pair | Same result |
|---|---:|
| AI review vs official | 10 / 40 |
| AI review vs independent | 35 / 40 |
| Official vs independent | 9 / 40 |

**Caveat on the comparison:** the AI review used the 10 review criteria, not the draft outcome rule, so this compares judgements only loosely.
- **Biggest gap:** C7 / D7, on the 27 cases both scored. AI review mean 3.04; official D7 mean 2.19.
- **Source of the gap:** whether a rule or deciding fact stated before the first attempt counts as leakage (§3).

## 2. Flagged cases (preserved; for priority comparison after unsealing)

### EXP-C58A: Contradictory or answer-revealing correction

- **Original case id:** `LTB-TA2-T04`. Role: tier1 (not calibration). Transcript shown to reviewers: run 1.
- **Finding:** In the same reply the tutor lists "*watch → watches*" and then sets "Correct the verb: 'My dad watch TV after dinner.'" The form tested by the next item is given before the learner tries it.
- **Across runs:** **Run 1 only.** Run 2 lists *do → does, wash → washes* (different verbs, no leak); run 3 gives no verb list. Official PARTIAL in all three runs; independent MEETS in all three.
- **Automated results:** run 1: official **PARTIAL** (D7 2), independent **MEETS** (D7 3) · run 2: official **PARTIAL** (D7 2), independent **MEETS** (D7 3) · run 3: official **PARTIAL** (D7 2), independent **MEETS** (D7 3).
- **AI review:** C7 = 1, C8 = 2, C6 = 4, C10 = 2, overall *partially meets*, major defect: yes.

Verbatim tutor reply (run 1, turn 2, as shown to reviewers):

> Correct: **"She goes to bed at ten."** You fixed it yourself, too.
> 
> The verb follows **she**, so it needs an ending. For *go*, that ending is **-es**, so it becomes **goes**. Other verbs like this: *do → does*, *watch → watches*.
> 
> Next one:
> 
> **Correct the verb: "My dad watch TV after dinner."**
> 
> Write the full sentence. Then tell me which word in the sentence tells you the verb needs to change.

### EXP-D688: Potentially revealing hint

- **Original case id:** `LTB-CA2-T05`. Role: tier1 (not calibration). Transcript shown to reviewers: run 2.
- **Finding:** After a failed attempt the hint says "Who **goes** to bed?", which contains the target form.
- **Across runs:** **Run 2 only.** Runs 1 and 3 point at "go" and "She" without giving the form. Official PARTIAL in all three runs.
- **Automated results:** run 1: official **PARTIAL** (D7 2), independent **PARTIAL** (D7 2) · run 2: official **PARTIAL** (D7 2), independent **MEETS** (D7 3) · run 3: official **PARTIAL** (D7 2), independent **MEETS** (D7 3).
- **AI review:** C7 = 2, C8 = 3, C6 = 4, C10 = 3, overall *meets expectations*, major defect: no.

Verbatim tutor reply (run 2, turn 2, as shown to reviewers):

> Nice try! You added **usually**, and it's in the right place, before the verb. 👍
> 
> But one word still needs fixing. Look at the verb **go** in your sentence. Who goes to bed? Check the word **go** again.
> 
> Can you write the sentence one more time?

### EXP-892B: Priority comparison case

- **Original case id:** `LTB-AB1-T04`. Role: tier1 (not calibration). Transcript shown to reviewers: run 1.
- **Finding:** Support rises after a correct answer (the deciding concept "ever" is explained before item 2). Internal labels `[ex1]` / `[ex2]` are shown to the learner.
- **Across runs:** The `[ex1]` / `[ex2]` labels appear in **all three runs** (systematic). Run 2's first reply also models "*I have never seen snow*" (the ex2 answer form, *seen*) before ex2 is set.
- **Automated results:** run 1: official **PARTIAL** (D7 2), independent **MEETS** (D7 3) · run 2: official **PARTIAL** (D7 2), independent **MEETS** (D7 3) · run 3: official **PARTIAL** (D7 2), independent **MEETS** (D7 3).
- **AI review:** C7 = 2, C8 = 3, C6 = 4, C10 = 3, overall *meets expectations*, major defect: no.

Verbatim tutor reply (run 1, turn 2, as shown to reviewers):

> Correct: **"I visited my aunt in aswan last year."** "Last year" is a finished time, so the past simple **visited** is the right form. One small slip: city names take a capital letter, so it's **Aswan**.
> 
> Now the other side of the lesson: an experience question with **no** finished time.
> 
> **[ex2] Choose: "___ you ever ___ (see) a camel?"**
> 
> Before you write, look at the word **ever**. It asks about any time in your life up to now, not a specific finished time.
> 
> Write the full question. Then add a one-line answer about yourself, using the same tense as the question.

### EXP-4137: Priority comparison case

- **Original case id:** `LTB-AA1-T02`. Role: tier1 (not calibration). Transcript shown to reviewers: run 1.
- **Finding:** The A1 check question "your mother's daughter (not you) is your mother or your sister?" is harder than the word it tests.
- **Across runs:** The confusing check question is **run 1 only**. Runs 2 and 3 use clearer checks ("Your mother has a son… Write: 'He is my ___.'"), but define mother as "the woman who **has you**", which is unnatural English (also noted by the AI review in another case).
- **Automated results:** run 1: official **PARTIAL** (D7 n/a), independent **MEETS** (D7 3) · run 2: official **PARTIAL** (D7 3), independent **MEETS** (D7 n/a) · run 3: official **PARTIAL** (D7 3), independent **MEETS** (D7 3).
- **AI review:** C7 = NA, C8 = 3, C6 = 2, C10 = 3, overall *meets expectations*, major defect: no.

Verbatim tutor reply (run 1, turn 1, as shown to reviewers):

> Good question. No, a **sister** is not your mother.
> 
> - **mother** = the woman who is your parent
> - **sister** = a girl or woman with the same mother and father as you
> 
> Example (mine):
> *This is my mother. She is a teacher.*
> *This is my sister. She is ten.*
> 
> Our goal: introduce family with "This is my …" and "He is / She is …".
> 
> Quick check: your mother's daughter (not you) is your **mother** or your **sister**?

## 3. Investigation: pre-attempt rule disclosure and answer-form leakage (all 3 runs × 120 cases)

**Method:**
- Every lesson-item presentation and every hint turn in `run_{1,2,3}/live/raw_results.jsonl` was scanned with documented patterns (`restricted/investigation_results.json`, script `tools/fin_investigate.py`).
- **Every answer-form match was then classified by hand.** The automatic counts alone overstate leakage: see §3.2.

### 3.1 Rule stated before the first attempt (systematic)

| Measure | Result |
|---|---|
| Item presentations before any attempt on that item | 287 |
| …with the item's rule stated in the same reply | **175/287 (61%)** (a lower bound; see precision note) |
| By lesson | Talking about my family: 26/102 (25%); My daily routine: 63/89 (71%); Life experiences: 86/96 (90%) |
| By run | run 1: 57/93 (61%); run 2: 59/97 (61%); run 3: 59/97 (61%) |
| Family (he/she) items: deciding fact stated ("brother … boy") | 20/102 (20%) |

**Precision note:**
- A hand check of 8 random matches found 8 true rule statements.
- 2 of 6 random non-matches also contained a rule or deciding-fact cue that the pattern missed ("the verb changes… I play → My cat plays"; "is a brother a boy or a girl? Then choose He").
- **So the true rate is at least 61%.** It is identical across runs, which means it is **not sampling noise**.

**Probable source (tutor instructions; read-only observation, not changed):**
- The `present_lesson_item` move text says: *"present the lesson item given below exactly as written (you may add one short line of instruction or **a reminder of the pattern using a different example**, never this item's answer)"*.
- The tutor follows this, so the pre-attempt rule reminder is **sanctioned by current policy**.
- **Whether it is acceptable is educator decision 1 / 6.** It must not be changed before that ruling.

### 3.2 Answer form shown before an attempt or in a hint (hand-classified)

| Category (hand classification) | Turns | Cases | Notes |
|---|---:|---:|---|
| Pattern matches before an attempt | 33 | 19 | Automatic count |
| … false positive: meta-language ("every day **goes** at the end") | 7 | | Not a leak |
| … learner's own or present-perfect use ("a place you **have visited**") | 4 | | Not the answer form |
| … **item's answer form in a worked example or rule with the same verb** | **10** | **7** | "go → **goes**", "My sister **goes** to school" (LTB-CA2-T09 in **all 3 runs**), "I watch the news → He **watches**" (LTB-AA2-T04 run 2), "I have never **seen** snow" (LTB-AB1-T04 run 2), "I **visited** the pyramids last year" (LTB-TB1-T11 runs 1 and 3), plus EXP-C58A run 1 |
| … answer form incidentally in another sentence ("means you **visited** Luxor", "Maria **goes** to work") | 12 | | Weaker; still shows the form |
| Pattern matches in a hint after a failed attempt | 29 | 11 | Automatic count |
| … learner's own wrong answer quoted back ("You built **have visited** correctly") | 27 | | Not a leak |
| … analogy to an already-completed item ("Think about 'she **goes**' from the last exercise") | 1 | | Not a leak of this item |
| … **target form in the hint** | **1** | **1** | EXP-D688 run 2 only |

**C58A pattern (next item's answer listed, then the item set in the same reply):** 2 occurrences in 360 case-runs. They are LTB-TA2-T04 run 1 (EXP-C58A) and LTB-AA2-T04 run 2. Neither repeats in the other runs of the same case.

### 3.3 Internal exercise labels shown to the learner

- **Frequency:** "[ex1]" / "[ex2]" appear in 23 of 657 tutor replies, across 12 cases.
- **Cause:** the tutor's lesson-item lines are written as "[ex1] …" with "present … exactly as written", and the tutor sometimes copies the label.
- **Product finding:** cosmetic, not pedagogical. Not changed.

### 3.4 Interpretation (for the coordinator; not a ruling)

1. **Rule-before-attempt** is the tutor's default and is policy-sanctioned. Its acceptability is the central educator decision. It also explains most of the official evaluator's D7 = 2 scores and the official-vs-AI-review gap.
2. **Answer-form leakage proper is real but much rarer:**
   - about 10 pre-attempt turns in 7 cases, plus 1 hint, across 360 case-runs;
   - it is mostly a worked example that reuses the item's own verb, against the "different example" wording.
   - It is a **separate** issue from rule disclosure and should be scored separately (educator decision 6, option c).
3. **Flagged single instances do not repeat** in the other runs (EXP-C58A, EXP-D688). Treat them as sampling-dependent model behaviour, not deterministic engine behaviour.
4. **Recommended after educator rulings (not before):** decide whether "different example" must use a different verb; then re-measure on ≥ 3 runs.

## 4. Handling rules for this package

- `educator_rubric_decisions.md` / `.pdf` (copies in this folder, byte-identical to v1) stay **restricted**. Give them to the educators only **after independent scoring and adjudication are complete**.
- Rubric v2 and the scoring code are unchanged (hash-verified in `final_package_manifest.json`).
- No human scoring has started. Nothing has been sent or shared externally.
